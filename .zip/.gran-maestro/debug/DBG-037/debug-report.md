# DBG-037 디버그 리포트: 백업 버튼 작동 불가

## 참여 조사자
- codex (프론트엔드 백업 버튼 이벤트 핸들러 및 API 엔드포인트 추적): done
- codex-2 (전체 메뉴별 백업 버튼 구현 패턴 스캔 및 비교 분석): done
- claude (백업 기능 아키텍처 설계 의도 분석 및 서버 사이드 백업 로직 검증): done

## 백업 버튼 소재 전수 조사

| 뷰 | 파일 | handleBackup 위치 | EditModeToolbar 연결 |
|----|------|-------------------|---------------------|
| DebugView | `frontend/src/views/DebugView.tsx` | :213-234 | :254-260 |
| WorkflowView | `frontend/src/views/WorkflowView.tsx` | :405-424 | :639-645 |
| PlansView | `frontend/src/views/PlansView.tsx` | :305-324 | 확인 필요 |
| IdeationView | `frontend/src/views/IdeationView.tsx` | :312-331 | 확인 필요 |

- 공통 컴포넌트: `frontend/src/components/EditModeToolbar.tsx`
- 서버 엔드포인트: `src/routes/manage.ts:166` (`POST /manage/backup`)

## 핵심 발견 (교차 검증 완료)

### P0: 에러 피드백 완전 부재 (확신도: 높음 — 3/3 조사자 확인)

4개 뷰 모두 `handleBackup`의 catch 블록에서 `console.error`만 수행. 사용자에게 시각적 피드백(alert, 토스트 등)이 **전혀 없음**.

```typescript
// 현재 패턴 (4개 뷰 동일)
catch (err) {
  console.error('백업 실패:', err);
  // ← 사용자에게 아무런 알림 없음
}
```

대조적으로, 같은 뷰의 `handleStatusChange`는 `alert()`으로 에러를 표시함.

**영향 파일**:
- `DebugView.tsx:231-233`
- `WorkflowView.tsx:423-425`
- `PlansView.tsx:323` (추정)
- `IdeationView.tsx:330-332`

### P0: 백업 진행 상태 표시 없음 (확신도: 높음 — 2/3 확인)

백업 버튼 클릭 시 로딩 인디케이터 없음. zip 생성에 시간이 걸리면 사용자는 버튼이 반응하지 않는 것으로 인지.

### P1: 3단계 워크플로우 인지 문제 (확신도: 높음 — 2/3 확인)

백업 실행을 위해 **편집 모드 진입 → 항목 체크박스 선택 → 백업 클릭**의 3단계가 필요.
- `EditModeToolbar.tsx:38-44`: `isEditMode === false`이면 백업 버튼이 DOM에 없음
- `EditModeToolbar.tsx:76-83`: `disabled={selectedIds.length === 0}` — 선택 없으면 비활성

### P2: 서버 로직 자체는 구조적으로 정상 (확신도: 중간 — 런타임 미검증)

`src/routes/manage.ts:166-241`의 백업 흐름:
1. `resolveBaseDir(projectId)` → 프로젝트 기본 디렉토리
2. `resolveItemDir(baseDir, rawId)` → ID별 디렉토리 매핑
3. `zip` 명령어로 압축 → 바이너리 응답 반환

**잠재 위험**: `resolveItemDir`이 지원하는 ID 패턴(REQ/PLN/DBG/IDN 등)에 포함되지 않는 ID 유형이 있을 수 있음.

## 근본 원인 종합 진단

**"버튼이 작동하지 않는다"의 가장 유력한 원인 조합:**

1. **에러 피드백 부재** — 서버에서 에러가 발생해도(400/500) 사용자에게 아무 표시 없이 실패가 무시됨
2. **진행 상태 없음** — 클릭 후 아무 반응이 보이지 않아 "작동 안 함"으로 인지
3. **서버 사이드 실패 가능성** — 브라우저 콘솔에서 실제 에러 응답 코드를 확인해야 확정 가능

서버 코드 자체는 구조적으로 올바르나, **런타임에서 실제로 성공하는지는 브라우저 콘솔/네트워크 탭 확인이 필요**.

## 수정 제안 (우선순위 순)

### P0 — 에러 피드백 + 로딩 상태 추가 (4개 뷰 공통)

```typescript
const [isBackingUp, setIsBackingUp] = useState(false);

const handleBackup = async () => {
  setIsBackingUp(true);
  try {
    // ... 기존 fetch 로직 ...
  } catch (err) {
    console.error('백업 실패:', err);
    alert('백업에 실패했습니다. 선택한 항목을 확인해주세요.');
  } finally {
    setIsBackingUp(false);
  }
};
```

대상: `DebugView.tsx`, `WorkflowView.tsx`, `PlansView.tsx`, `IdeationView.tsx`

### P1 — 서버 사이드 에러 원인 확인

브라우저 콘솔/네트워크 탭에서 백업 API 호출의 실제 응답 코드와 바디를 확인하여 근본 원인 확정 필요.

### P2 — UX 개선 (선택적)

편집 모드 없이 개별 항목을 바로 백업할 수 있는 단건 백업 버튼 추가 고려.

## 추가 조사 필요 영역

1. 브라우저 콘솔에서 백업 시도 시 실제 에러 로그 확인
2. `resolveItemDir`이 지원하는 ID 패턴 전수 확인 (누락 유형 있는지)
3. `projectId` 값이 프론트엔드에서 정상 세팅되는지 확인
