# DBG-037: 백업 버튼 작동 불가 — 서버 사이드 및 아키텍처 분석

## 조사 요약

대시보드의 백업 버튼(EditModeToolbar 컴포넌트) 기능 전체를 프론트엔드(4개 뷰)와 서버 사이드(manage.ts 라우트) 양쪽에서 추적하여, 버튼이 작동하지 않는 원인을 조사했다.

## 발견 사항

### 1. 백업 버튼의 `disabled` 조건 — 선택 없이 클릭 불가 (UX 문제)

- **파일**: `frontend/src/components/EditModeToolbar.tsx:76-83`
- 백업 버튼은 `disabled={selectedIds.length === 0}` 조건이 있어, 편집 모드에서 항목을 하나 이상 체크해야 활성화된다.
- 사용자가 편집 모드 진입 후 항목을 선택하지 않으면 버튼이 비활성 상태로 보이며, 이것이 "작동하지 않는다"고 인지될 수 있다.

### 2. 백업 버튼은 편집 모드에서만 노출

- **파일**: `frontend/src/components/EditModeToolbar.tsx:38-44`
- `isEditMode === false`이면 "편집" 버튼만 렌더링되고 백업 버튼은 DOM에 존재하지 않는다.
- 편집 모드 진입 -> 체크박스로 항목 선택 -> 백업 클릭, 이 3단계 워크플로우를 사용자가 인지하지 못할 수 있다.

### 3. 프론트엔드 handleBackup에서 fetch를 직접 사용 (apiFetch 미사용)

- **파일**: `frontend/src/views/DebugView.tsx:213-234`
- `handleBackup`은 `apiFetch`가 아닌 네이티브 `fetch`를 직접 사용한다 (blob 응답 때문).
- URL 구성: `projectId ? /api/projects/${projectId}/manage/backup : /api/manage/backup`
- **문제**: `projectId`가 `undefined`이면 `/api/manage/backup`으로 요청이 간다. 서버 측 `app.route("/api", projectApi)`로 매핑되므로 `projectId` 파라미터가 없고, `resolveBaseDir(undefined)`가 호출된다.
  - HUB_MODE가 아닌 경우: `BASE_DIR`을 반환하므로 정상.
  - HUB_MODE이고 프로젝트가 2개 이상: `null` 반환 -> 404 에러.

### 4. 서버 백업 로직의 `zip` 명령어 의존성

- **파일**: `src/routes/manage.ts:213-218`
- 서버는 `Deno.Command("zip", ...)` 로 시스템의 `zip` 바이너리를 실행한다.
- **잠재적 문제**: `zip`이 설치되지 않은 환경에서는 실행 실패. macOS는 기본 포함이지만, 일부 Linux 환경에서는 미설치 가능.

### 5. 에러 핸들링 — 사용자에게 에러 표시 없음

- **파일**: `frontend/src/views/DebugView.tsx:223,231-233`
- `!response.ok`이면 `throw new Error`하지만, catch 블록에서는 `console.error`만 수행.
- 사용자에게 alert이나 토스트 등 시각적 피드백이 전혀 없다 (상태 변경의 경우 `alert`를 사용하는 것과 대조적).
- 4개 뷰 모두 동일한 패턴: `PlansView.tsx:305-324`, `WorkflowView.tsx:405-424`, `IdeationView.tsx:312-331`.

### 6. 서버 응답이 JSON이 아닌 바이너리일 때의 에러 분기

- **파일**: `src/routes/manage.ts:200-203`
- `itemDirs.length === 0`이면 `c.json({ error: "No valid ids" }, 400)` — JSON 응답.
- 프론트엔드는 `response.blob()`으로 읽으므로, 400 에러 시 JSON 에러 바디가 blob으로 읽히고 `.zip` 파일로 다운로드 시도. 결과적으로 깨진 zip 파일이 저장된다 (단, `!response.ok` 체크가 있어 이 경우는 throw됨).

## 근본 원인 분석

백업 버튼이 "작동하지 않는" 주요 원인은 **UX 흐름 인지 문제**와 **에러 피드백 부재**의 복합이다:

1. **워크플로우 인지**: 편집 모드 -> 항목 선택 -> 백업 클릭의 3단계가 필요하지만, 버튼 자체가 편집 모드에서만 보인다.
2. **에러 무시**: 서버에서 에러가 발생해도 `console.error`만 출력하므로 사용자는 아무 반응 없이 버튼 클릭이 무시된 것으로 느낀다.
3. **서버 로직 자체는 정상**: `manage.ts`의 백업 엔드포인트 로직은 구조적으로 올바르며, `resolveItemDir`로 디렉토리를 찾고 `zip`으로 압축 후 바이너리 응답을 반환한다.

## 수정 제안

### P1: 에러 피드백 추가 (4개 뷰 공통)

```typescript
// catch 블록에 사용자 피드백 추가
catch (err) {
  console.error('백업 실패:', err);
  alert('백업에 실패했습니다. 항목을 선택했는지 확인해주세요.');
}
```

대상 파일: `DebugView.tsx:231`, `PlansView.tsx:323`, `WorkflowView.tsx:423`, `IdeationView.tsx:330`

### P2: 백업 진행 상태 표시

백업 버튼 클릭 시 로딩 상태를 표시하여 사용자가 동작 중임을 인지할 수 있도록 한다 (`isBackingUp` state 추가).

### P3: 편집 모드 없이 개별 항목 백업

현재 디테일 패널에서 개별 항목을 바로 백업하는 버튼이 없다. 편집 모드 진입 없이 단건 백업이 가능한 UX를 고려할 수 있다.

## 추가 조사 필요 영역

1. **브라우저 콘솔 로그 확인**: 실제 백업 시도 시 콘솔에 어떤 에러가 출력되는지 확인 필요 (404, 400, 500 등).
2. **projectId 유무 확인**: 프론트엔드에서 `projectId`가 정상적으로 세팅되는지, `useAppContext()`의 반환값 점검.
3. **HUB_MODE 여부 확인**: 현재 서버가 HUB_MODE로 동작 중인지에 따라 `resolveBaseDir`의 동작이 달라짐.
4. **`zip` 바이너리 가용성**: 서버 실행 환경에서 `which zip` 확인.
5. **CORS 또는 네트워크 문제**: 개발 환경에서 프록시 설정이나 포트 불일치로 요청 자체가 실패하는지 확인.
